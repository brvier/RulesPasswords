.controller('DialogController', function($scope) {
  
  $scope.next = function() {
    $scope.dialog.hide();
    ons.createDialog('dialog.html').then(function(dialog) {
      dialog.show();
    });
  }
  
  $scope.show = function(dlg) {
    ons.createDialog(dlg).then(function(dialog) {
      dialog.show();
    });
  }
});